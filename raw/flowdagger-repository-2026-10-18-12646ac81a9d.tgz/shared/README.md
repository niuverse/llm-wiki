# shared

Framework-agnostic pieces reused by the FlowDAgger backends.

- `experts/` scripted experts that read privileged simulator state and return
  corrective actions. `base_expert.py` defines the interface;
  `metaworld_expert.py` and `libero_expert.py` implement it.
- `task_configs.py` the task registry consumed by the trainers.
- `intervention_handler.py` decides when the expert takes over during a rollout
  (beta-decay schedule or action-disagreement modes) and, when an inverter and
  action converter are supplied, logs the inverted initial-latent targets.

Import these as a package from a backend, with the repo root on `sys.path`:

```python
from shared.experts.metaworld_expert import MetaworldScriptedExpert
from shared.experts.libero_expert import LiberoExpert
from shared.intervention_handler import InterventionHandler
from shared.task_configs import get_task_config
```
