"""Prompt contract tests."""
