"""Workspace verifier tests."""
